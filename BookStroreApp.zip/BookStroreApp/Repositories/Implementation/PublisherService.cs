﻿using BookStroreApp.Models.Domain;
using BookStroreApp.Repositories.Abstract;

namespace BookStroreApp.Repositories.Implementation
{
    public class PublisherService :IPublisherService
    {
        private readonly DatabaseContext context;
        public PublisherService(DatabaseContext context)
        {
            this.context = context;
            
        }

        public bool Add(Publisher model)
        {
            try
            {
                context.Publisher.Add(model);
                context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }

        public bool Delete(int id)
        {
            try
            {
                var data = this.FindById(id);
                if (data == null)
                {
                    return true;
                }
                context.Publisher.Remove(data);
                context.SaveChanges();
                return true;

            }
            catch (Exception e)
            {
                return false;
            }
        }

        public Publisher FindById(int id)
        {
            return context.Publisher.Find(id);
        }
        IEnumerable<Publisher> IPublisherService.GetAll()
        {
            return context.Publisher.ToList();
        }
        public bool Update(Publisher model)
        {
            try
            {
                context.Publisher.Update(model);
                context.SaveChanges();
                return true;

            }
            catch (Exception e)
            {
                return false;
            }
        }

       
    }
}
