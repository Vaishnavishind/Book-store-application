﻿using BookStroreApp.Models.Domain;
namespace BookStroreApp.Repositories.Abstract

{
    public interface IGenreService
    {

        bool Add(Genre model);

        bool Update(Genre Model);

        bool Delete(int id);

        Genre FindById(int id);

        IEnumerable<Genre> GetAll();

    }
}

