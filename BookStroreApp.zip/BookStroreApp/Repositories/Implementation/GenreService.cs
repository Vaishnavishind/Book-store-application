﻿using BookStroreApp.Models.Domain;
using BookStroreApp.Repositories.Abstract;

namespace BookStroreApp.Repositories.Implementation
{
    public class GenreService : IGenreService
    {
        private readonly DatabaseContext context;
        public GenreService(DatabaseContext context)
        {
            this.context = context;
            
        }

        public bool Add(Genre model)
        {
            try
            {
                context.Genre.Add(model);
                context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }

        public bool Delete(int id)
        {
            try
            {
                var data = this.FindById(id);
                if (data == null)
                {
                    return true;
                }
                context.Genre.Remove(data);
                context.SaveChanges();
                return true;

            }
            catch (Exception e)
            {
                return false;
            }
        }

        public Genre FindById(int id)
        {
            return context.Genre.Find(id);
        }
        IEnumerable<Genre> IGenreService.GetAll()
        {
            return context.Genre.ToList();
        }
        public bool Update(Genre model)
        {
            try
            {
                context.Genre.Update(model);
                context.SaveChanges();
                return true;

            }
            catch (Exception e)
            {
                return false;
            }
        }

        
    }
}
