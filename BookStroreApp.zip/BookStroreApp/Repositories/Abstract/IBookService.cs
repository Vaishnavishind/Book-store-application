﻿using BookStroreApp.Models.Domain;

namespace BookStroreApp.Repositories.Abstract
{
    public interface IBookService
    {
        bool Add(Book model);

        bool Update(Book Model);

        bool Delete(int id);

        Book FindById(int id);

        IEnumerable<Book> GetAll();
    }
}
